﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace JWTAuthentication
{
    public class JwtService
    {
        private readonly IConfiguration config;

        public JwtService(IConfiguration config)
        {
            this.config = config;
        }


        public async Task<ActionResult<int>> Login(User request)
        {
            var result = await Authenticate(request);
            if (result is null)
            {
                return 0;
            }

            return 1;
        }

        public async Task<User> Authenticate(User request)
        {
            if (string.IsNullOrWhiteSpace(request.UserName))
                return null;


            var userAccount = (request.UserName == "CorrectOne") ? request : null;

            if (userAccount is null)
                return null;

            var issuer = config["Jwt:Issuer"];
            var audience = config["Jwt:Audience"];
            var key = config["Jwt:SigningKey"];

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[]
                {
                    new Claim(JwtRegisteredClaimNames.Name, request.UserName)
                }),
                Issuer = issuer,
                Audience = audience,
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(key)),
                SecurityAlgorithms.HmacSha256)
             };

            var tokenHandler = new JwtSecurityTokenHandler();
            var securityToken = tokenHandler.CreateToken(tokenDescriptor);
            var accessToken = tokenHandler.WriteToken(securityToken);

            return new User { AccessToken = accessToken, UserName = request.UserName };

            
        }
    }
}
