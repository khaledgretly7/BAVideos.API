﻿using System.ComponentModel.DataAnnotations;

namespace JWTAuthentication
{
    public class User
    {
        [Required]
        public string UserName { get; set; }
        public string? EmailAddress { get; set; }
        public string? AccessToken { get; set; }
    }
}
