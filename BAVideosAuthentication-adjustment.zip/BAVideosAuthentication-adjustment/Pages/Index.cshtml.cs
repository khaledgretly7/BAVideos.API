using JWTAuthentication;
using JWTAuthentication.Controllers;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Threading.Channels;

namespace BibALEXsite.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly JwtService jwtService;
        private readonly IConfiguration configuration;

        public IndexModel(ILogger<IndexModel> logger, JwtService jwtService, IConfiguration config)
        {
            this.jwtService = jwtService;
            _logger = logger;
            this.configuration = config;
        }

        [BindProperty]
        public User Login { get; set; } = default!;

        public async Task<IActionResult> OnPost()
        {

            if (!ModelState.IsValid)
            {
                return Page();
            }

 
            if (Login != null) { 
                User x = await jwtService.Authenticate(Login); 
                TempData["Token"] = x.AccessToken;
                if (TempData["RequestUrl"] != null)
                {
                    return Redirect(configuration["Jwt:Callback"] + TempData["Token"] + "?requestUrl=" + TempData["RequestUrl"]);
                }
                else
                {
                    return Redirect(configuration["Jwt:Callback"] + TempData["Token"]);
                }
            }
            
 

            return Page();
        }

        public void OnGet(string? requestUrl)
        {
            if (requestUrl != null) TempData["RequestUrl"] = requestUrl;
        }
    }
}
