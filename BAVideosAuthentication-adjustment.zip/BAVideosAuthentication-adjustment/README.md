<a name='assembly'></a>
# Authentication using JSON Web Tokens

## Contents
- [About JSON Web Tokens](#T-JWTIntro 'About JSON Web Tokens')
- [UserController](#T-JWTAuthentication-Controllers-UserController 'JWTAuthentication.Controllers.UserController')
  - [Login(request)](#M-JWTAuthentication-Controllers-UserController-Login-JWTAuthentication-User- 'JWTAuthentication.Controllers.UserController.Login(JWTAuthentication.User)')

<a name='T-JWTIntro'></a>
## About JSON Web Tokens
JSON Web Token (JWT) is an open standard (RFC 7519) that defines a compact and self-contained way for securely transmitting information between parties as a JSON object. This information can be verified and trusted because it is digitally signed. JWTs can be signed using a secret (with the HMAC algorithm) or a public/private key pair using RSA or ECDSA.

In this project, HMAC SHA256 is utilised.

<a name='T-JWTAuthentication-Controllers-UserController'></a>
## UserController `type`

##### Namespace

JWTAuthentication.Controllers

##### Summary

Controller that handles the login and token creation and authentication.

<a name='M-JWTAuthentication-Controllers-UserController-Login-JWTAuthentication-User-'></a>
### Login(request) `method`

##### Summary

Logs in the user and, if a valid user, creates a JWT token.

##### Returns

JWT Token.

##### Parameters

| Name | Type | Description |
| ---- | ---- | ----------- |
| request | [JWTAuthentication.User](User.cs 'JWTAuthentication.User') | The user credentials. |
