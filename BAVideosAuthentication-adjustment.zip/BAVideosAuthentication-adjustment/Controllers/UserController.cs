﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication.JwtBearer;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace JWTAuthentication.Controllers
{

    /// <summary>
    /// Controller that handles the login and token creation and authentication.
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private JwtService jwtService;

        public UserController(JwtService jwtService)
        {
            this.jwtService = jwtService;
        }

        //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        //[HttpGet]
        //public string Get()
        //{
        //    return "Lol";
        //}

        /// <summary>
        /// Logs in the user and, if a valid user, creates a JWT token.
        /// </summary>
        /// <param name="request">The user credentials.</param>
        /// <returns>JWT Token.</returns>
        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult<User>> Login(User request)
        {
            var result = await jwtService.Authenticate(request);
            if (result is null)
            {
                return Unauthorized();
            }

            return result;
        }
    }
}
